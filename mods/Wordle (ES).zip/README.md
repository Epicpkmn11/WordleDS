This example of Wordle DS translated to Spanish, based on Daniel Rodriguez's [Wordle (ES)](https://wordle.danielfrg.com).

Este es un ejemplo de Wordle DS traducido al Español, basado en el [Wordle (ES)](https://wordle.danielfrg.com) por Daniel Rodriguez.
