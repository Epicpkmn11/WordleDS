English:

An Italian translation mod for WordleDS by a brownboi, a non-italian using Google Translate and an Italian word bank. (Italian word bank from https://github.com/pietroppeter/wordle-it)

Installation:
Just like any other WordleDS mod, copy the Wordle (IT) folder from the same directory as this message to _nds/WordleDS

If there's any Italian speakers here please point out any grammar issues to brownboi on the Universal Server

This mod has been tested on 2 DSis, a hacked 2DS, a DS Lite with TwilightMenu on a DSTT and MelonDS all using WordleDS v2.0.0

Utilities used:
https://github.com/pietroppeter/wordle-it https://convertcase.net
http://www.unit-conversion.info/texttools/replace-text/
https://lingojam.com/TexttoOneLine
https://miniwebtool.com/remove-spaces/
https://onlinerandomtools.com/shuffle-words
https://www.gimp.org



Italiano:

Una mod di traduzione italiana per WordleDS da parte di un brownboi, un non italiano che utilizza Google Translate e una banca di parole italiane. (Banca di parole italiane da https://github.com/pietroppeter/wordle-it)

Installazione:
Proprio come qualsiasi altra mod di WordleDS, copia la cartella Wordle (IT) dalla stessa directory di questo messaggio in _nds / WordleDS

Se ci sono persone che parlano italiano qui si prega di segnalare eventuali problemi di grammatica su brownboi sull'Universal Server

Questa mod è stata testata su 2 DSi, un 2DS hackerato, un DS Lite con TwilightMenu su un DSTT e MelonDS tutti usando WordleDS v2.0.0

Problemi noti:
Impossibile passare alla modalità difficile durante l'utilizzo di WordleDS in italiano. Dovrai attivare la modalità difficile mentre sei in vaniglia WordleDS, quindi passare a Italian Wordle

Utilità utilizzate:
https://github.com/pietroppeter/wordle-ithttps://convertcase.net
http://www.unit-conversion.info/texttools/replace-text/
https://lingojam.com/TexttoOneLine
https://miniwebtool.com/remove-spaces/
https://onlinerandomtools.com/shuffle-words
https://www.gimp.org
